const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const authRoutes = require('./routes/auth');
const path = require('path');

const app = express();


app.set('view engine', 'ejs');

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, 'public')));


app.use((req, res, next) => {
    if (!req.session.user && req.path !== '/auth/login' && req.path !== '/auth/register') {
       
        return res.redirect('/auth/login');
    } else if (req.session.user && req.path === '/') {
        
        return res.redirect('/auth/profile');
    }
    next();
});


app.use('/auth', authRoutes);


app.get('/', (req, res) => {
    if (req.session.user) {
        return res.redirect('/auth/profile');
    } else {
        return res.redirect('/auth/login');
    }
});

// Dashboard
app.get('/dashboard', (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    res.render('dashboard');
});

// CRUD pemantauan
app.get('/pemantauan', (req, res) => {
    db.query('SELECT * FROM pemantauan', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.render('datapemantauan', { data: results });
    });
});

app.post('/pemantauan/add', (req, res) => {
    const { nama, jumlah, status, lokasi } = req.body;
    db.query('INSERT INTO pemantauan (nama, jumlah, status, lokasi) VALUES (?, ?, ?)', [nama, jumlah, status, lokasi], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pemantauan');
    });
});

app.post('/pemantauan/edit/:id', (req, res) => {
    const { id } = req.params;
    const { nama, tipe, plat } = req.body;
    db.query('UPDATE pemantauan SET nama = ?, jumlah = ?, status = ?, lokasi =? ', [nama, jumlah, status, lokasi], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pemantauan');
    });
});

app.get('/pemantauan/delete/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM pemantauan WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pemantauan');
    });
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});



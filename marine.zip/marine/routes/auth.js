const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../config/db");
const router = express.Router();

// Halaman Register
router.get("/register", (req, res) => {
    res.render("register");
});

// Proses Register
router.post("/register", async (req, res) => {
    try {
        const { username, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);

        db.query("INSERT INTO users (username, password) VALUES (?, ?)", [username, hashedPassword], (err) => {
            if (err) {
                console.error("Database insert error:", err);
                return res.status(500).send("Database error");
            }
            res.redirect("/login");
        });
    } catch (err) {
        console.error("Error during registration:", err);
        res.status(500).send("Internal server error");
    }
});

// Halaman Login
router.get("/login", (req, res) => {
    res.render("login");
});

// Proses Login
router.post("/login", async (req, res) => {
    try {
        const { username, password } = req.body;

        db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
            if (err) {
                console.error("Database query error:", err);
                return res.status(500).send("Database error");
            }
            if (results.length > 0) {
                const user = results[0];
                const isMatch = await bcrypt.compare(password, user.password);

                if (isMatch) {
                    req.session.user = user;
                    res.redirect("/profile");
                } else {
                    res.send("Password salah!");
                }
            } else {
                res.send("Username tidak ditemukan!");
            }
        });
    } catch (err) {
        console.error("Error during login:", err);
        res.status(500).send("Internal server error");
    }
});

// Halaman Profile (Setelah Login)
router.get("/profile", (req, res) => {
    if (!req.session.user) return res.redirect("/login");
    res.render("profile", { user: req.session.user });
});

// Proses Logout
router.post("/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error("Session destroy error:", err);
            return res.status(500).send("Could not log out");
        }
        res.redirect("/login");
    });
});

module.exports = router;
